var canvas = document.getElementById("myCanvas");
var context = canvas.getContext("2d");
canvas.width = 800;
canvas.height = 600;

var firstTime = true;
var throwGift = false;
var score = 0;

const santaIMG = new Image();
santaIMG.src = "santa.png";
const presentIMG = new Image();
presentIMG.src ="gift.png";
const kids1IMG = new Image();
kids1IMG.src ="kid.png";
const backgroundIMG = new Image();
backgroundIMG.src ="bg.jpg";

const rand = function(num) {
  //the given function that makes a random number
  return Math.floor(Math.random() * num) + 1;
};

const santa = {
  x: 20,
  y: 200,
  width: 150,
  height: 150,
  image: santaIMG,
  xDelta: 0,
  yDelta: 0,
  speed: 9,
  moveUp: false,
  moveDown: false,
  moveLeft: false,
  moveRight: false
};

const kid = {
  x: 690,
  y: rand(canvas.height - 50),
  width: 100,
  height: 100,
  image: kids1IMG,
  xDelta: 0,
  yDelta: 0,
  speed: 5
};

const present = {
  x: 100,
  y: 200,
  width: 50,
  height: 50,
  image: presentIMG,
  xDelta: 0,
  yDelta: 0,
  speed: 8
};

const updating = function() {


  if (santa.moveUp === true) {
    //if the key is presed the santa will move smoothly.
    santa.y -= 10;
  }
  if (santa.moveDown === true) {
    santa.y += 10;
  }
  if (santa.moveLeft === true) {
    santa.x -= 10;
  }
  if (santa.moveRight === true) {
    santa.x += 10;
  }
  if (santa.y >= canvas.height - 150) {
    //if santa hits the canvas border it will stay in it's position
    santa.y = canvas.height - 150;
  }
  if (santa.y <= 0) {
    santa.y = 0;
  }
  if (santa.x >= canvas.width - 200) {
    santa.x = canvas.width - 200;
  }
  if (santa.x <= 0) {
    santa.x = 0;
  }

  //kid and present clash part
  if((present.x >= kid.x - 10 && present.x <= kid.x + 10) && (present.y <= kid.y + 80 && present.y >= kid.y - 80) && throwGift == true)
  {
    kid.x = 690;
    kid.y= rand(canvas.height - 50);
    present.x = 100;
    throwGift = false;
    context.clearRect(present.x,present.y,present.width,present.height);
    context.clearRect(kid.x,kid.y,kid.width,kid.height);
    context.drawImage(backgroundIMG, 0, 0);
    context.drawImage(santa.image, santa.x, santa.y, santa.width, santa.height);
    score += 1;
    document.getElementById("score").innerHTML = 'Your Score : ' + score;

  }

    //for repeating the kid's movements
    if(kid.x <= -106)
    {
      kid.x = 690;
      kid.y= rand(canvas.height - 50);
    }

    kid.x = kid.x + kid.speed;

    // the boundary conditions
    if(kid.x >= canvas.width-kid.width){
      kid.speed *= -1;
    }

    kid.x++;

    //present throw part
    if(throwGift)
    {   
      if(present.x >= 810)
      {
        throwGift = false;
        present.x = 100;
      }
      else{
        present.x = present.x + present.speed;

        present.x++;
      }
    }
    if(kid.x < santa.x + santa.width && kid.x + kid.width > santa.x && kid.y < santa.y + santa.height && santa.height + 
      kid.y > santa.y) {    
      alert("Oops!!! GAME OVER!!!");
    location.reload();
  };


};

const drawing = function() {
  //draws canvas color and the draw function of the test for its objects
  context.drawImage(backgroundIMG, 0, 0);
  context.drawImage(santa.image, santa.x, santa.y, santa.width, santa.height); //draws the santa
  context.drawImage(kid.image, kid.x, kid.y, kid.width, kid.height);
  if(throwGift){
    context.drawImage(present.image, present.x, present.y, present.width, present.height);
  }

};


const run = function() {
  //makes a loop called run so it runs the drawing and updating functions we made
  drawing();
  updating();  
  requestAnimationFrame(run);
  
};

run();
const leftKey = 37;
const upKey = 38;
const rightKey = 39;
const downKey = 40;
const space = 32;


document.addEventListener(
  "keydown",
  function(event) {
    //if key is pressed changing the false(moveUP and ...) of santa to true so it moves

    if (event.keyCode === upKey) {
      santa.moveUp = true;
    } else if (event.keyCode === downKey) {
      santa.moveDown = true;
    } else if (event.keyCode === rightKey) {
      santa.moveRight = true;
    } else if (event.keyCode === leftKey) {
      santa.moveLeft = true;
    }
    else if(event.keyCode === space)
    {
      throwGift = true;
      present.y =santa.y;
    }
  },
  false
  );
document.addEventListener(
  "keyup",
  function(event) {
    //if key is released changing the true (moveUP and ...) to false

    if (event.keyCode === upKey) {
      santa.moveUp = false;
    } else if (event.keyCode === downKey) {
      santa.moveDown = false;
    }

    if (event.keyCode === rightKey) {
      santa.moveRight = false;
    } else if (event.keyCode === leftKey) {
      santa.moveLeft = false;
    }
  },
  false
  );
